﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApiSimple.Models;

namespace WebApiSimple.Repositories
{
    /// <summary>
    /// Pets' Memory Repository
    /// </summary>
    public class PetRepository
    {
        private static IDictionary<int, PetModel> memoryRepo = new Dictionary<int, PetModel>();

        static PetRepository()
        {
            var pets = new[]
            {
                new PetModel { Id = 1, Name = "Max", Kind = PetKind.Dog },
                new PetModel { Id = 2, Name = "Lulu", Kind = PetKind.Cat },
                new PetModel { Id = 3, Name = "Luke", Kind = PetKind.Bird },
            };

            foreach (var pet in pets)
            {
                memoryRepo.Add(pet.Id, pet);
            }
        }

        public IQueryable<PetModel> Get()
        {
            return memoryRepo.Values.AsQueryable();
        }

        public PetModel Get(int id)
        {
            return memoryRepo[id];
        }

        public PetModel Add(PetModel pet)
        {
            memoryRepo.Add(pet.Id, pet);
            return pet;
        }

        public PetModel Update(PetModel pet)
        {
            memoryRepo[pet.Id] = pet;
            return pet;
        }

        public void Delete(PetModel pet)
        {
            memoryRepo.Remove(pet.Id);
        }

        public int GetNewId()
        {
            return memoryRepo.Count + 1;
        }
    }
}
