﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebApiSimple.Models
{
    /// <summary>
    /// The type of pet
    /// </summary>
    public enum PetKind
    {
        /// <summary>
        /// Dog
        /// </summary>
        Dog,
        /// <summary>
        /// Cat
        /// </summary>
        Cat,
        /// <summary>
        /// Bird
        /// </summary>
        Bird
    }
}
