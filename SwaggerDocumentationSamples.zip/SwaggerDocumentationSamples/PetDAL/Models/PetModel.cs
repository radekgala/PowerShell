﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebApiSimple.Models
{
    /// <summary>
    /// Pet
    /// </summary>
    public class PetModel
    {
        /// <summary>
        /// unique pet Id 
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// Pet's Name
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Animal grade
        /// </summary>
        public PetKind Kind { get; set; }
    }
}
