﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Owin;
using Owin;
using Swashbuckle.Application;
using System.Web.Http;


[assembly: OwinStartup(typeof(WebApiSample.Simple.Startup))]

namespace WebApiSample.Simple
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            HttpConfiguration config = new HttpConfiguration();

            // Register Web APi
            WebApiConfig.Register(config);

			// Katana middleware for configure your application to use WebApi
			app.UseWebApi(config);

			// Register Swagger ( Web api documantation )
			SwaggerConfig.Register(config);
        }
    }
}
