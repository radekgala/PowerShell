﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using System.Web.Http.Description;
using WebApiSimple.Models;
using WebApiSimple.Repositories;
using Swashbuckle.Swagger.Annotations;
using System.Net;

namespace WebApiSample.Simple.Controllers
{
    /// <summary>
    /// Pet - a Web Api to manage Pets in Store 
    /// </summary>
    public class PetController : ApiController
    {
        private readonly PetRepository petRepository;

        public PetController()
        {
            petRepository = new PetRepository();
        }


        /// <summary>
        /// Get all pets
        /// </summary>
        /// <returns>All pets</returns>        
        public IEnumerable<PetModel> Get()
        {
            return petRepository.Get().ToList();
        }


        /// <summary>
        /// Find pet by ID
        /// </summary>
        /// <param name="id">The Id of the pet.</param>        
        /// <returns></returns>          
        [SwaggerResponse(HttpStatusCode.OK, Description = "Ok", Type = typeof(PetModel))]
        [SwaggerResponse(HttpStatusCode.NotFound, Description = "Not Found")]
        public IHttpActionResult Get(int id)
        {
            var pet = petRepository.Get(id);
            if(pet != null)
            {
                return Ok(pet);
            }
            else
            {
                return NotFound();
            }            
        }


        /// <summary>
        /// Adds new pet to the store 
        /// </summary>          
        public void Post(PetModel pet)
        {
            pet.Id = petRepository.GetNewId();
            petRepository.Add(pet);
        }

        
        /// <summary>
        /// Update an existing pet in the store
        /// </summary>
        public void Put(int id, PetModel pet)
        {
            petRepository.Update(pet);
        }


        /// <summary>
        /// Deletes a pet
        /// </summary>                
        public void Delete(int id)
        {
            var pet = petRepository.Get(id);
            petRepository.Delete(pet);
        }
    }
}
