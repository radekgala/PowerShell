﻿using System.Web.Http;
using Swashbuckle.Application;
using System;
using System.IO;
using System.Net.Http;
using System.Collections.Generic;
using WebApiSimple.Models;
using System.Linq;


namespace WebApiSample.Simple
{
    public class SwaggerConfig
    {
        public static void Register(HttpConfiguration configuration)
        {                        
            configuration
                .EnableSwagger(c =>
                    {
                        c.SingleApiVersion("v1", "Pets Shop")
                        .Description("This is sample web application for Silesia University");
                        
                        c.RootUrl(req =>
                            req.RequestUri.GetLeftPart(UriPartial.Authority) +
                            req.GetRequestContext().VirtualPathRoot.TrimEnd('/')
                        );

                        
                        foreach (string path in GetXmlCommentsPath())
                        {
                            c.IncludeXmlComments(path);
                        }

                    })
                .EnableSwaggerUi(c =>
                    {
                        c.DisableValidator();
                    });
        }


        private static IEnumerable<string> GetXmlCommentsPath()
        {
            var baseDirectory = AppDomain.CurrentDomain.BaseDirectory;

            var assemblies = new[] {
                // assembly where controllers are defined (current)
                typeof(SwaggerConfig).Assembly,
                // data models assemblies
                typeof(PetModel).Assembly
            };

            return assemblies.Select(a => Path.Combine(baseDirectory, "bin", a.GetName().Name + ".xml"));
        }
    }
}
